@echo off
REM Builds AttendanceAgent.exe (needs Python 3.9+ installed on the build PC only)
pip install pyinstaller
pyinstaller --onefile --noconsole --name AttendanceAgent attendance_agent.py
copy /Y config.json dist\config.json
echo.
echo Done. Copy the contents of the "dist" folder to each PC (e.g. C:\AttendanceAgent\)
pause
