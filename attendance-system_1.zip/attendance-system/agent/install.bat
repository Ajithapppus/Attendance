@echo off
REM Run once on each employee PC (right-click > Run as administrator).
REM Installs the agent to start automatically when ANY user logs in.
REM It must run in the user's session (not as a service) to read idle time.
set TARGET=C:\AttendanceAgent
mkdir "%TARGET%" 2>nul
copy /Y "%~dp0AttendanceAgent.exe" "%TARGET%\" >nul
copy /Y "%~dp0config.json" "%TARGET%\" >nul
schtasks /Create /TN "AttendanceAgent" /TR "\"%TARGET%\AttendanceAgent.exe\"" /SC ONLOGON /RL LIMITED /F
start "" "%TARGET%\AttendanceAgent.exe"
echo Installed. The agent is running.
pause
