@echo off
schtasks /Delete /TN "AttendanceAgent" /F
taskkill /IM AttendanceAgent.exe /F
rmdir /S /Q C:\AttendanceAgent
echo Removed.
pause
