"""
Attendance Agent (Windows) - minimal-data heartbeat sender.

Sends ONLY: device ID (PC name), optional employee ID, online state, and
seconds since last keyboard/mouse input (a single number).

It does NOT capture screenshots, keystrokes, window titles, passwords,
files, browsing history, or any private content.

Run:  python attendance_agent.py            (normal)
      python attendance_agent.py --show-data (print exactly what is sent, once)
"""
import ctypes
import json
import logging
import os
import socket
import sys
import time
import urllib.error
import urllib.request

APP_DIR = os.path.dirname(sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__))
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
LOG_PATH = os.path.join(APP_DIR, "agent.log")

logging.basicConfig(filename=LOG_PATH, level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]


def idle_seconds() -> float:
    """Seconds since the last keyboard/mouse input in the current user session."""
    info = LASTINPUTINFO()
    info.cbSize = ctypes.sizeof(info)
    if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
        return 0.0
    tick = ctypes.windll.kernel32.GetTickCount() & 0xFFFFFFFF
    return ((tick - info.dwTime) & 0xFFFFFFFF) / 1000.0


def load_config() -> dict:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    if not cfg.get("web_app_url") or not cfg.get("token"):
        raise SystemExit("config.json: web_app_url and token are required")
    cfg.setdefault("device_id", "")
    cfg.setdefault("employee_id", "")
    cfg.setdefault("interval_seconds", 60)
    cfg["device_id"] = cfg["device_id"] or socket.gethostname()
    return cfg


def build_payload(cfg: dict) -> dict:
    return {
        "token": cfg["token"],
        "deviceId": cfg["device_id"],
        "employeeId": cfg["employee_id"],
        "state": "online",
        "idleSeconds": int(idle_seconds()),
    }


def send(cfg: dict, payload: dict) -> bool:
    req = urllib.request.Request(
        cfg["web_app_url"],
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "text/plain;charset=utf-8"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            body = resp.read().decode("utf-8", "replace")
        ok = '"ok":true' in body.replace(" ", "")
        if not ok:
            logging.warning("Server rejected heartbeat: %s", body[:200])
        return ok
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        logging.warning("Heartbeat failed (will retry): %s", exc)
        return False


def single_instance() -> bool:
    """Prevent two copies running on the same PC."""
    ctypes.windll.kernel32.CreateMutexW(None, False, "Global\\AttendanceAgentMutex")
    return ctypes.windll.kernel32.GetLastError() != 183  # ERROR_ALREADY_EXISTS


def main() -> None:
    cfg = load_config()
    if "--show-data" in sys.argv:
        shown = build_payload(cfg)
        shown["token"] = "***hidden***"
        print("This is the ONLY data sent every cycle:")
        print(json.dumps(shown, indent=2))
        return
    if not single_instance():
        return
    logging.info("Agent started for device %s", cfg["device_id"])
    while True:
        send(cfg, build_payload(cfg))
        time.sleep(max(15, int(cfg["interval_seconds"])))


if __name__ == "__main__":
    main()
