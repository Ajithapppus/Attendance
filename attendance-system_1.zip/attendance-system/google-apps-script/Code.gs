/***********************************************************************
 * Computer Attendance & Monitoring System  -  Google Apps Script
 * Paste into Extensions > Apps Script, then run  setup()  once.
 ***********************************************************************/

const TZ = Session.getScriptTimeZone();
const DASH = 'Attendance Dashboard';
const HEADERS = ['Employee ID', 'Employee Name', 'Department', 'Assigned Computer / PC Name',
  'Login Time', 'Last Computer Activity', 'Current Status', 'Attendance Status',
  'Inactive Duration', 'Notice', 'Date', 'Remarks'];
// column indexes (0-based) in the daily sheet
const C = { ID: 0, NAME: 1, DEPT: 2, PC: 3, LOGIN: 4, LAST: 5, STATUS: 6, ATT: 7, INACT: 8, NOTICE: 9, DATE: 10, REMARKS: 11 };

const STATUS_STYLE = {
  'Active': ['#d9f2e0', '#0b6b2e'],
  'Inactive': ['#fff1cc', '#8a5a00'],
  'Not Using Computer': ['#ffd9b3', '#9a3d00'],
  'Computer Offline': ['#e3e3e3', '#444444'],
  'No Login': ['#ffd6d6', '#a30000'],
  'Waiting': ['#e6eefc', '#1a3d8f'],
  'Day Ended': ['#eeeeee', '#666666'],
  'Non-working day': ['#eeeeee', '#666666'],
  'Present': ['#d9f2e0', '#0b6b2e'],
  'Late': ['#fff1cc', '#8a5a00'],
  'Absent': ['#ffd6d6', '#a30000']
};

/* ===================== MENU / SETUP ===================== */

function onOpen() {
  SpreadsheetApp.getUi().createMenu('Attendance')
    .addItem('Initial setup', 'setup')
    .addItem('Refresh now', 'refreshStatuses')
    .addItem("Create today's sheet", 'createDailySheet')
    .addToUi();
}

function setup() {
  const ss = SpreadsheetApp.getActive();
  buildSettings_(ss);
  buildEmployees_(ss);
  buildHolidays_(ss);
  buildHeartbeats_(ss);
  buildSearch_(ss);
  createDailySheet();
  installTriggers_();
  refreshStatuses();
  SpreadsheetApp.getUi().alert('Setup complete.\n\nNext: Deploy > New deployment > Web app '
    + '(Execute as: Me, Access: Anyone), copy the URL and the API Token (Settings sheet) into each PC\'s agent config.json.');
}

function installTriggers_() {
  ScriptApp.getProjectTriggers().forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('refreshStatuses').timeBased().everyMinutes(5).create();
  ScriptApp.newTrigger('createDailySheet').timeBased().everyDays(1).atHour(0).nearMinute(5).create();
}

function buildSettings_(ss) {
  if (ss.getSheetByName('Settings')) return;
  const sh = ss.insertSheet('Settings');
  const rows = [
    ['Setting', 'Value', 'Notes'],
    ['Working Start Time', '09:00', 'HH:mm (24h)'],
    ['Working End Time', '18:00', 'HH:mm (24h)'],
    ['Inactivity Threshold (min)', 15, 'Idle this long = "Inactive" + notice'],
    ['Escalation Threshold (min)', 30, 'Idle this long = "Not Using Computer" + email/Chat alert'],
    ['Grace Period (min)', 15, 'After start time before "No Login / Absent" and "Late"'],
    ['Offline After (min)', 5, 'No heartbeat this long = "Computer Offline"'],
    ['Notification Email', '', 'Admin email for alerts (comma-separated allowed)'],
    ['Google Chat Webhook URL (optional)', '', 'Space webhook for alerts'],
    ['Working Days', 'Mon,Tue,Wed,Thu,Fri', 'Comma-separated: Mon,Tue,Wed,Thu,Fri,Sat,Sun'],
    ['API Token', Utilities.getUuid().replace(/-/g, ''), 'Secret used by the PC agents - keep private']
  ];
  sh.getRange(1, 1, rows.length, 3).setValues(rows);
  sh.getRange('B2:B3').setNumberFormat('@').setValues([['09:00'], ['18:00']]);
  sh.getRange('A1:C1').setFontWeight('bold').setBackground('#1a3d8f').setFontColor('#fff');
  sh.getRange('B2:B11').setBackground('#fffbe6');
  sh.setColumnWidths(1, 1, 260); sh.setColumnWidths(2, 1, 280); sh.setColumnWidths(3, 1, 420);
  sh.setFrozenRows(1);
}

function buildEmployees_(ss) {
  if (ss.getSheetByName('Employees')) return;
  const sh = ss.insertSheet('Employees');
  sh.getRange(1, 1, 1, 5).setValues([['Employee ID', 'Employee Name', 'Department', 'Assigned Computer / PC Name', 'Active (Yes/No)']])
    .setFontWeight('bold').setBackground('#1a3d8f').setFontColor('#fff');
  sh.getRange(2, 1, 3, 5).setValues([
    ['E001', 'Rahul', 'Marketing', 'PC-01', 'Yes'],
    ['E002', 'Arun', 'Development', 'PC-02', 'Yes'],
    ['E003', 'Neha', 'Design', 'PC-03', 'Yes']]);
  sh.setColumnWidths(1, 5, 190); sh.setFrozenRows(1);
}

function buildHolidays_(ss) {
  if (ss.getSheetByName('Holidays')) return;
  const sh = ss.insertSheet('Holidays');
  sh.getRange('A1:B1').setValues([['Holiday Date', 'Name']]).setFontWeight('bold').setBackground('#1a3d8f').setFontColor('#fff');
  sh.getRange('A2:A').setNumberFormat('dd-MM-yyyy');
  sh.setColumnWidths(1, 2, 200);
}

function buildHeartbeats_(ss) {
  if (ss.getSheetByName('Heartbeats')) return;
  const sh = ss.insertSheet('Heartbeats');
  sh.getRange('A1:E1').setValues([['Computer', 'Employee ID (reported)', 'Last Seen', 'Last Activity', 'State']])
    .setFontWeight('bold').setBackground('#444').setFontColor('#fff');
  sh.getRange('C2:D').setNumberFormat('dd-MM-yyyy HH:mm:ss');
  sh.setColumnWidths(1, 5, 180);
}

function buildSearch_(ss) {
  if (ss.getSheetByName('Search')) return;
  const sh = ss.insertSheet('Search');
  sh.getRange('A1').setValue('Employee Search').setFontSize(18).setFontWeight('bold');
  sh.getRange('A3').setValue('Enter Employee Name / ID / Computer:').setFontWeight('bold');
  sh.getRange('B3').setBackground('#fffbe6').setBorder(true, true, true, true, false, false);
  sh.getRange('Z1').setFormula('=TEXT(TODAY(),"dd-MM-yyyy")&" Attendance"');
  sh.getRange('A5:L5').setValues([HEADERS]).setFontWeight('bold').setBackground('#1a3d8f').setFontColor('#fff');
  const t = (c) => `INDIRECT("'"&$Z$1&"'!${c}")`;
  sh.getRange('A6').setFormula(
    `=IFERROR(FILTER(${t('A2:L')},(ISNUMBER(SEARCH($B$3,${t('A2:A')}))+ISNUMBER(SEARCH($B$3,${t('B2:B')}))` +
    `+ISNUMBER(SEARCH($B$3,${t('D2:D')})))*(${t('A2:A')}<>"")),"No match found")`);
  sh.getRange('E6:F200').setNumberFormat('HH:mm');
  sh.getRange('I6:I200').setNumberFormat('0" min"');
  sh.setColumnWidths(1, 12, 150);
  sh.hideColumns(26);
  applyStatusFormatting_(sh, 'G6:H200');
}

/* ===================== SETTINGS HELPERS ===================== */

function getSettings_() {
  const sh = SpreadsheetApp.getActive().getSheetByName('Settings');
  const m = {};
  sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 1), 2).getValues()
    .forEach(r => { if (r[0]) m[String(r[0]).trim()] = r[1]; });
  const num = (k, d) => (isNaN(Number(m[k])) || m[k] === '' ? d : Number(m[k]));
  return {
    start: timeToMin_(m['Working Start Time'], 540),
    end: timeToMin_(m['Working End Time'], 1080),
    threshold: num('Inactivity Threshold (min)', 15),
    escalation: num('Escalation Threshold (min)', 30),
    grace: num('Grace Period (min)', 15),
    offline: num('Offline After (min)', 5),
    email: String(m['Notification Email'] || '').trim(),
    chat: String(m['Google Chat Webhook URL (optional)'] || '').trim(),
    days: String(m['Working Days'] || 'Mon,Tue,Wed,Thu,Fri').split(',').map(s => s.trim().slice(0, 3).toLowerCase()),
    token: String(m['API Token'] || '').trim()
  };
}

function timeToMin_(v, def) {
  if (v instanceof Date) v = Utilities.formatDate(v, TZ, 'HH:mm');
  const p = String(v || '').split(':');
  if (p.length < 2 || isNaN(p[0]) || isNaN(p[1])) return def;
  return Number(p[0]) * 60 + Number(p[1]);
}

function minOfDay_(d) { return Number(Utilities.formatDate(d, TZ, 'H')) * 60 + Number(Utilities.formatDate(d, TZ, 'm')); }
function fmt_(d, p) { return Utilities.formatDate(d, TZ, p); }

function isWorkingDay_(d, s) {
  const names = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const dow = names[Number(fmt_(d, 'u')) % 7];
  if (s.days.indexOf(dow) < 0) return false;
  const sh = SpreadsheetApp.getActive().getSheetByName('Holidays');
  if (!sh || sh.getLastRow() < 2) return true;
  const key = fmt_(d, 'yyyy-MM-dd');
  return !sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues().some(r =>
    r[0] instanceof Date ? fmt_(r[0], 'yyyy-MM-dd') === key : String(r[0]).trim() === key);
}

/* ===================== DAILY SHEET ===================== */

function dailyName_(d) { return fmt_(d, 'dd-MM-yyyy') + ' Attendance'; }

function createDailySheet() {
  const s = getSettings_();
  const now = new Date();
  if (!isWorkingDay_(now, s)) return null;
  return ensureDailySheet_(now);
}

function ensureDailySheet_(d) {
  const ss = SpreadsheetApp.getActive();
  const name = dailyName_(d);
  let sh = ss.getSheetByName(name);
  if (sh) return sh;
  sh = ss.insertSheet(name);
  const emp = ss.getSheetByName('Employees').getDataRange().getValues().slice(1)
    .filter(r => r[0] && String(r[4]).trim().toLowerCase() !== 'no');
  const rows = emp.map(r => [r[0], r[1], r[2], r[3], '', '', 'Waiting', 'Pending', '', '', fmt_(d, 'dd-MM-yyyy'), '']);
  sh.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS])
    .setFontWeight('bold').setBackground('#1a3d8f').setFontColor('#fff').setWrap(true);
  if (rows.length) sh.getRange(2, 1, rows.length, HEADERS.length).setValues(rows);
  sh.getRange('K2:K').setNumberFormat('@');
  sh.getRange('E2:F').setNumberFormat('HH:mm');
  sh.getRange('I2:I').setNumberFormat('0" min"');
  sh.setFrozenRows(1);
  sh.setColumnWidths(1, 12, 140); sh.setColumnWidth(10, 320); sh.setColumnWidth(12, 220);
  applyStatusFormatting_(sh, 'G2:H500');
  return sh;
}

function applyStatusFormatting_(sh, a1) {
  const range = sh.getRange(a1);
  const rules = sh.getConditionalFormatRules();
  Object.keys(STATUS_STYLE).forEach(k => rules.push(
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo(k)
      .setBackground(STATUS_STYLE[k][0]).setFontColor(STATUS_STYLE[k][1]).setRanges([range]).build()));
  sh.setConditionalFormatRules(rules);
}

/* ===================== HEARTBEAT ENDPOINT ===================== */

function doGet() { return json_({ ok: true, service: 'attendance' }); }

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    const p = JSON.parse(e.postData.contents);
    const s = getSettings_();
    if (!s.token || p.token !== s.token) return json_({ ok: false, error: 'unauthorized' });
    const device = String(p.deviceId || '').trim();
    if (!device) return json_({ ok: false, error: 'deviceId required' });

    const now = new Date();
    const idle = Math.max(0, Number(p.idleSeconds) || 0);
    const lastActivity = new Date(now.getTime() - idle * 1000);

    upsertHeartbeat_(device, String(p.employeeId || ''), now, lastActivity, String(p.state || 'online'));

    if (!isWorkingDay_(now, s)) return json_({ ok: true, note: 'non-working day' });
    const sh = ensureDailySheet_(now);
    const last = sh.getLastRow();
    if (last < 2) return json_({ ok: false, error: 'no employees' });
    const pcs = sh.getRange(2, C.PC + 1, last - 1, 1).getValues();
    const idx = pcs.findIndex(r => String(r[0]).trim().toLowerCase() === device.toLowerCase());
    if (idx < 0) return json_({ ok: false, error: 'device not mapped to an employee' });
    const row = idx + 2;
    if (!sh.getRange(row, C.LOGIN + 1).getValue()) sh.getRange(row, C.LOGIN + 1).setValue(now);
    sh.getRange(row, C.LAST + 1).setValue(lastActivity);
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  } finally {
    try { lock.releaseLock(); } catch (x) { /* ignore */ }
  }
}

function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

function upsertHeartbeat_(device, empId, seen, last, state) {
  const sh = SpreadsheetApp.getActive().getSheetByName('Heartbeats');
  const n = sh.getLastRow() - 1;
  const names = n > 0 ? sh.getRange(2, 1, n, 1).getValues() : [];
  const i = names.findIndex(r => String(r[0]).toLowerCase() === device.toLowerCase());
  const vals = [[device, empId, seen, last, state]];
  sh.getRange(i < 0 ? sh.getLastRow() + 1 : i + 2, 1, 1, 5).setValues(vals);
}

/* ===================== STATUS ENGINE (every 5 min) ===================== */

function refreshStatuses() {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const s = getSettings_();
    const now = new Date();
    const sh = ensureDailySheet_(now);
    const n = sh.getLastRow() - 1;
    if (n < 1) return;

    const data = sh.getRange(2, 1, n, HEADERS.length).getValues();
    const hbSheet = SpreadsheetApp.getActive().getSheetByName('Heartbeats');
    const hbRows = hbSheet.getLastRow() > 1 ? hbSheet.getRange(2, 1, hbSheet.getLastRow() - 1, 4).getValues() : [];
    const seenMap = {};
    hbRows.forEach(r => { seenMap[String(r[0]).toLowerCase()] = r[2]; });

    const working = isWorkingDay_(now, s);
    const nowM = minOfDay_(now);
    const alerts = [];

    const out = data.map(r => {
      let status, att, inact = '', notice = '';
      const login = r[C.LOGIN], last = r[C.LAST];
      if (!working) { status = 'Non-working day'; att = '-'; }
      else if (nowM < s.start) { status = 'Waiting'; att = 'Pending'; }
      else if (!login) {
        if (nowM > s.start + s.grace) { status = 'No Login'; att = 'Absent'; notice = 'No login detected'; }
        else { status = 'Waiting'; att = 'Pending'; }
      } else {
        att = minOfDay_(login) > s.start + s.grace ? 'Late' : 'Present';
        const idleMin = last instanceof Date ? Math.floor((now - last) / 60000) : 0;
        const seen = seenMap[String(r[C.PC]).toLowerCase()];
        const seenAge = seen instanceof Date ? Math.floor((now - seen) / 60000) : 9999;
        if (nowM > s.end) { status = 'Day Ended'; inact = r[C.INACT]; notice = r[C.NOTICE]; }
        else if (seenAge > s.offline) {
          status = 'Computer Offline'; inact = idleMin;
          notice = 'Attention: Computer offline / not detected for ' + seenAge + ' minutes.';
        } else if (idleMin >= s.escalation) {
          status = 'Not Using Computer'; inact = idleMin;
          notice = 'Attention: No computer activity detected for ' + idleMin + ' minutes.';
        } else if (idleMin >= s.threshold) {
          status = 'Inactive'; inact = idleMin;
          notice = 'Attention: No computer activity detected for ' + idleMin + ' minutes.';
        } else { status = 'Active'; inact = idleMin; }
      }
      if (['Not Using Computer', 'Computer Offline', 'No Login'].indexOf(status) >= 0) {
        alerts.push({ id: r[C.ID], name: r[C.NAME], pc: r[C.PC], status: status, notice: notice });
      }
      return [status, att, inact, notice];
    });

    sh.getRange(2, C.STATUS + 1, n, 4).setValues(out);
    data.forEach((r, i) => { r[C.STATUS] = out[i][0]; r[C.ATT] = out[i][1]; r[C.INACT] = out[i][2]; r[C.NOTICE] = out[i][3]; });

    sendAlerts_(alerts, s, now);
    updateDashboard_(data, now);
  } finally {
    lock.releaseLock();
  }
}

/* ===================== NOTIFICATIONS ===================== */

function sendAlerts_(alerts, s, now) {
  const props = PropertiesService.getScriptProperties();
  const today = fmt_(now, 'yyyyMMdd');
  const all = props.getProperties();
  Object.keys(all).forEach(k => { if (k.indexOf('alert|') === 0 && k.indexOf('alert|' + today) !== 0) props.deleteProperty(k); });

  const fresh = alerts.filter(a => {
    const key = ['alert', today, a.id, a.status].join('|');
    if (props.getProperty(key)) return false;
    props.setProperty(key, '1');
    return true;
  });
  if (!fresh.length) return;

  const lines = fresh.map(a => `- ${a.name} (${a.id}, ${a.pc}): ${a.status}. ${a.notice}`);
  const body = `Attendance alerts - ${fmt_(now, 'dd-MM-yyyy HH:mm')}\n\n` + lines.join('\n');
  if (s.email) MailApp.sendEmail(s.email, 'Attendance alert: ' + fresh.length + ' employee(s)', body);
  if (s.chat) {
    UrlFetchApp.fetch(s.chat, { method: 'post', contentType: 'application/json',
      payload: JSON.stringify({ text: body }), muteHttpExceptions: true });
  }
}

/* ===================== DASHBOARD ===================== */

function updateDashboard_(rows, now) {
  const ss = SpreadsheetApp.getActive();
  const d = ss.getSheetByName(DASH) || ss.insertSheet(DASH, 0);
  d.clear(); d.clearConditionalFormatRules();
  d.getCharts().forEach(c => d.removeChart(c));
  d.setHiddenGridlines(true);

  const cnt = f => rows.filter(f).length;
  const total = rows.length;
  const present = cnt(r => r[C.ATT] === 'Present' || r[C.ATT] === 'Late');
  const pct = total ? present / total : 0;
  const statusList = ['Active', 'Inactive', 'Not Using Computer', 'Computer Offline', 'No Login'];

  d.getRange('A1').setValue('Attendance Dashboard').setFontSize(20).setFontWeight('bold');
  d.getRange('A2').setValue('Updated ' + fmt_(now, 'dd-MM-yyyy HH:mm')).setFontColor('#666');

  const kpi = [
    ['Total Employees', total],
    ['Active Employees', cnt(r => r[C.STATUS] === 'Active')],
    ['Inactive Employees', cnt(r => r[C.STATUS] === 'Inactive' || r[C.STATUS] === 'Not Using Computer')],
    ['Computer Offline', cnt(r => r[C.STATUS] === 'Computer Offline')],
    ['No Login', cnt(r => r[C.STATUS] === 'No Login')],
    ['Attendance %', pct],
    ["Today's Attendance (Present + Late)", present + ' / ' + total]
  ];
  d.getRange(4, 1, kpi.length, 2).setValues(kpi);
  d.getRange('A4:A10').setFontWeight('bold').setBackground('#f1f4fb');
  d.getRange('B4:B10').setFontSize(13).setHorizontalAlignment('left');
  d.getRange('B9').setNumberFormat('0%');
  d.setColumnWidth(1, 270); d.setColumnWidth(2, 130);

  d.getRange('D3:E3').setValues([['Status', 'Employees']]).setFontWeight('bold').setBackground('#1a3d8f').setFontColor('#fff');
  d.getRange(4, 4, statusList.length, 2).setValues(statusList.map(k => [k, cnt(r => r[C.STATUS] === k)]));

  const head = ['Employee ID', 'Employee Name', 'Computer', 'Status', 'Inactive (min)', 'Latest Activity', 'Attendance'];
  d.getRange(13, 1, 1, 7).setValues([head]).setFontWeight('bold').setBackground('#1a3d8f').setFontColor('#fff');
  if (rows.length) {
    d.getRange(14, 1, rows.length, 7).setValues(rows.map(r => [
      r[C.ID], r[C.NAME], r[C.PC], r[C.STATUS], r[C.INACT],
      r[C.LAST] instanceof Date ? fmt_(r[C.LAST], 'HH:mm') : '-', r[C.ATT]]));
    d.getRange(14, 5, rows.length, 1).setNumberFormat('0" min"');
    applyStatusFormatting_(d, 'D14:D' + (13 + rows.length));
    applyStatusFormatting_(d, 'G14:G' + (13 + rows.length));
    applyStatusFormatting_(d, 'D4:D8');
  }
  d.setColumnWidths(3, 5, 150);

  d.insertChart(d.newChart().setChartType(Charts.ChartType.PIE)
    .addRange(d.getRange('D3:E8')).setNumHeaders(1)
    .setOption('title', 'Status distribution').setOption('width', 420).setOption('height', 260)
    .setPosition(3, 9, 0, 0).build());
  if (rows.length) {
    d.insertChart(d.newChart().setChartType(Charts.ChartType.BAR)
      .addRange(d.getRange(13, 2, rows.length + 1, 1)).addRange(d.getRange(13, 5, rows.length + 1, 1)).setNumHeaders(1)
      .setOption('title', 'Inactivity duration (min) by employee').setOption('legend', { position: 'none' })
      .setOption('width', 420).setOption('height', 300)
      .setPosition(19, 9, 0, 0).build());
  }
}
